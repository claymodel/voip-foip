#!/bin/bash
#
# callweaver_att_local.sh
# 29-Apr-2007
#
# http://messinet.com  
# <amessina@messinet.com>
#
# This script creates CallWeaver or Asterisk extension matches for area
# codes and prefixes which are treated as "Local Calls" by AT&T and do not
# incur local-toll or long-distance charges when called from the area code
# and prefix you enter here.
#
# The script downloads the current extensions and prefixes of types
# "Band A" and "Band B" from http://localcalling.sbc.com/LCA/lca_input.jsp.
#
# The resulting file contents should be included in the "trunklocal" context
# of your CallWeaver or Asterisk "extensions.conf" file.
#
##################
# DEFINE VARIABLES
##################
#
# YOU MUST DEFINE A VALID E-MAIL ADDRESS TO WHICH THE RESULTING
# FILE CONTENTS WILL BE SENT FOR INSPECTION.
PBX_ADMIN_EMAIL='root@example.com'
PBX_EMAIL_SUBJECT='[PBX:] Local extension matches updated'
#
# YOU MUST DEFINE THE FULL PATH TO YOUR "callweaver" OR "asterisk"
# EXECUTABLE ON THE CURRENT MACHINE SO EXTENSIONS CAN BE AUTOMATICALLY
# RELOADED.
PBX_EXEC='/usr/sbin/callweaver'
#
# Define the working /tmp directory.
TMP_DIR='/tmp'
#
# Define your date executable and format.
DATE=$(/bin/date +%c)
#
# Define the path to the "cp", "wget", "sed", "paste", "rm", "cat" and "mail" executables.
CP='/bin/cp'
WGET='/usr/bin/wget'
SED='/bin/sed'
PASTE='/usr/bin/paste'
RM='/bin/rm'
DIFF='/usr/bin/diff'
MAIL='/bin/mail'
#
##########################################
# EDIT THE LINES BELOW IF THEY DO NOT WORK
##########################################
#
# Now, gather some information from the user.
echo -e '\nThis script creates CallWeaver or Asterisk extension matches for area codes and prefixes\nwhich are treated as "Local Calls" by AT&T and do not incur local-toll or long-distance\ncharges when called from the area code and prefix you enter here.\n\nThe script downloads the current extensions and prefixes of types "Band A" and "Band B"\nfrom http://localcalling.sbc.com/LCA/lca_input.jsp.\n\nThe resulting file contents should be included in the "trunklocal" context of your\nCallWeaver or Asterisk "extensions.conf" file.\n'
echo -n 'Enter your 3-digit telephone area code: '
read AREACODE
echo -n 'Enter your 3-digit telephone prefix: '
read PREFIX
echo -n  'Enter the /path/to/output.filename: '
read OUTFILE
#
# Copy the current extension configuration to $OUTFILE.save
$CP -p $OUTFILE $OUTFILE.save
#
# Download the html file returned by AT&T and save it to "infile1" in the $TMP_DIR
# directory.
$WGET "http://localcalling.sbc.com/LCA/DispatchServlet?npa=$AREACODE&nxx=$PREFIX&myaction=com.sbc.it.sol.lcal.action.GetLocalCalls&from_page=input&all_local=all&display=web&sortby=type&provider=AIT" -O $TMP_DIR/infile1
#
# Strip extra stuff from the start of the file until we reach "Telephone
# Exchange" near the start of the listings table. Next, remove extra stuff
# including "Band C" from the first occurrence of "Band C" to the end of
# the file. Next, strip everything that's not a 3-digit number and arrange
# the 3-digit numbers in one column. Odd lines will contain area codes and
# even lines will contain prefixes. Next, delete empty lines and save the
# result to "infile2" in the $TMP_DIR directory.
$SED -e '1,/Telephone Exchange/ d' \
-e '/Band C/,$ d' \
-e 's/.\([0-9]\{3\}\)*/\1/g' \
-e '/^$/d'  < $TMP_DIR/infile1 > $TMP_DIR/infile2
#
# Append each even line to the preceding odd line with a space separating
# the contents and end the newly created line with "\n". This will create the
# resulting file "infile3" in the $TMP_DIR directory with contents formatted as:
# <areacode> <prefix>
# <areacode> <prefix>
# ...
$PASTE -s -d" \n" $TMP_DIR/infile2 > $TMP_DIR/infile3
#
# Remove the last line of the file (this would be the first area code and prefix
# in "Band C" - the local-toll area - that we do not want listed). Next, strip all
# spaces in the file. Next, create the extensions matches for your local area code
# as many of us are not allowed to dial 1+<areacode>+<number> when making
# calls from the same <areacode>. This assumes you have "TRUNKLOCALMSD"
# set to "5" in your "extensions.conf" file, so calls within your local areacode are
# sent out as just the local 7-digit number. Next, create the extension matches
# for all non-local area codes. This assumes you have "TRUNKMSD" set to "1"
# in your "extensions.conf" file. Next, insert a time/date comment at the top of the
# file. Next, write the resulting file to $OUTFILE.
$SED -e '$d' \
-e 's/ *//g'  \
-e 's/'"$AREACODE"'[0-9]\{3\}/exten => _91&XXXX,1,Dial(${TRUNK}\/w${EXTEN:${TRUNKLOCALMSD}})/' \
-e 's/^[0-9]\{6\}/exten => _91&XXXX,1,Dial(${TRUNK}\/w${EXTEN:${TRUNKMSD}})/' \
-e '1 i\; Created on '"$DATE"'.' < $TMP_DIR/infile3 > $OUTFILE
#
# Remove other files created during this process, leaving you with only $OUTFILE.
$RM $TMP_DIR/infile1 $TMP_DIR/infile2 $TMP_DIR/infile3
#
# E-Mail differences between $OUTFILE.save and $OUTFILE to an administrator to
# check for accuracy.
$DIFF $OUTFILE.save $OUTFILE 2>&1 | $MAIL -s "$PBX_EMAIL_SUBJECT" $PBX_ADMIN_EMAIL
#
# Reload CallWeaver or Asterisk extensions
$PBX_EXEC -rx "extensions reload"
